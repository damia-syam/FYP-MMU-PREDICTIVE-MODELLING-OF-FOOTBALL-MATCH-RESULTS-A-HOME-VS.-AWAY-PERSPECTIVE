import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score
from imblearn.over_sampling import SMOTE
from joblib import dump, load
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

# Load and prepare the data
df_clean_encode = pd.read_csv('FINAL CLEANED DATA.csv')

# Define features and target
features = df_clean_encode.columns[df_clean_encode.columns != 'Full_Time_Result_LabelEncoded']
target = 'Full_Time_Result_LabelEncoded'

# Split dataset into train and test sets
X = df_clean_encode[features]
y = df_clean_encode[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)

# Visualize class distributions after splitting
plt.figure()
sns.countplot(x='Full_Time_Result_LabelEncoded', data=y_train.to_frame())
plt.title('Class Distribution for Training Set')
plt.show()

plt.figure()
sns.countplot(x='Full_Time_Result_LabelEncoded', data=y_test.to_frame())
plt.title('Class Distribution for Testing Set')
plt.show()

# Normalize features
scaler = MinMaxScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# SMOTE for data balancing
smt = SMOTE(sampling_strategy='auto', random_state=42, k_neighbors=5)
X_res, y_res = smt.fit_resample(X_train_scaled, y_train)

# Initialize Random Forest classifier
rf = RandomForestClassifier(n_jobs=-1, random_state=42)

# Define the parameter grid for grid search
param_grid = {
    'n_estimators': [10, 20, 30, 40, 50, 60, 70],
    'max_depth': [None, 10, 20, 30, 40, 50, 60, 70],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
}

# Perform GridSearchCV
grid_search = GridSearchCV(rf, param_grid, cv=5, n_jobs=-1, scoring='accuracy')
grid_search.fit(X_res, y_res)

# Get the best model from GridSearchCV
best_model = grid_search.best_estimator_
best_params = grid_search.best_params_

# Save the best model
dump(best_model, 'best_random_forest_model.joblib')
print("Best Parameters:", best_params)

# Tkinter interface for predicting match outcomes
def predict_outcome():
    model = load('best_random_forest_model.joblib')
    
    # Prepare input features from the Tkinter interface
    features = [
        int(Half_Time_Result_LabelEncoded.get()),
        int(Half_Time_Home_Team_Goals.get()), 
        int(Half_Time_Away_Team_Goals.get()), 
        int(Home_Team_Shots_on_Target.get()), 
        int(Away_Team_Shots_on_Target.get()), 
        int(Away_Team_Shots.get()), 
        int(Home_Team_Shots.get()), 
        int(Home_Team_Yellow_Cards.get()), 
        int(Home_Team_Red_Cards.get()), 
        int(Away_Team_Red_Cards.get())
    ]
    
    # Predict using the loaded model
    prediction = model.predict([features])[0]
    result_mapping = {0: "Away Win", 1: "Draw", 2: "Home Win"}
    result = result_mapping[prediction]
    
    # Display prediction in a message box
    messagebox.showinfo("Prediction Result", f"The predicted result is: {result}")

# Tkinter GUI setup
root = tk.Tk()
root.title("Football Match Prediction System")

# Labels and entry fields for input features
tk.Label(root, text="Half Time Result (Away Win: 0, Draw: 1, Home Win: 2)").grid(row=0, column=0)
Half_Time_Result_LabelEncoded = tk.Entry(root)
Half_Time_Result_LabelEncoded.grid(row=0, column=1)

tk.Label(root, text="Number of Half Time Home Team Goals").grid(row=1, column=0)
Half_Time_Home_Team_Goals = tk.Entry(root)
Half_Time_Home_Team_Goals.grid(row=1, column=1)

tk.Label(root, text="Number of Half Time Away Team Goals").grid(row=2, column=0)
Half_Time_Away_Team_Goals = tk.Entry(root)
Half_Time_Away_Team_Goals.grid(row=2, column=1)

tk.Label(root, text="Number of Home Team Shots on Target").grid(row=3, column=0)
Home_Team_Shots_on_Target = tk.Entry(root)
Home_Team_Shots_on_Target.grid(row=3, column=1)

tk.Label(root, text="Number of Away Team Shots on Target").grid(row=4, column=0)
Away_Team_Shots_on_Target = tk.Entry(root)
Away_Team_Shots_on_Target.grid(row=4, column=1)

tk.Label(root, text="Number of Away Team Shots").grid(row=5, column=0)
Away_Team_Shots = tk.Entry(root)
Away_Team_Shots.grid(row=5, column=1)

tk.Label(root, text="Number of Home Team Shots").grid(row=6, column=0)
Home_Team_Shots = tk.Entry(root)
Home_Team_Shots.grid(row=6, column=1)

tk.Label(root, text="Number of Home Team Yellow Cards").grid(row=7, column=0)
Home_Team_Yellow_Cards = tk.Entry(root)
Home_Team_Yellow_Cards.grid(row=7, column=1)

tk.Label(root, text="Number of Home Team Red Cards").grid(row=8, column=0)
Home_Team_Red_Cards = tk.Entry(root)
Home_Team_Red_Cards.grid(row=8, column=1)

tk.Label(root, text="Number of Away Team Red Cards").grid(row=9, column=0)
Away_Team_Red_Cards = tk.Entry(root)
Away_Team_Red_Cards.grid(row=9, column=1)

# Button to predict outcome
predict_button = tk.Button(root, text="Predict Outcome", command=predict_outcome)
predict_button.grid(row=10, columnspan=2)

root.mainloop()
