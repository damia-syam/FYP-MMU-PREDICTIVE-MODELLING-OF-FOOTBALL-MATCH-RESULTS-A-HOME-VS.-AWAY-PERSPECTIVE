To run the best model interface for football match prediction (random forest), follow these steps:

1. Open the folder 12111304435_2689_Project Interface in VS Code.

2. Locate and open Main.py within the VS Code editor.

3. Run the Main.py script to launch the interface for the random forest model.

For any issues or inquiries, please contact me at on 12111304435@student.mmu.edu.my